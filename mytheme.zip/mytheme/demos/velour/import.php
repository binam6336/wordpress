<?php
require_once __DIR__ . '/layout.php';
require_once dirname( __DIR__, 2 ) . '/inc/demo-import.php';
$catalog = json_decode( file_get_contents( __DIR__ . '/catalog.json' ), true );
$steps = array();
foreach ( $catalog['images'] as $key => $filename ) {
	$steps[] = static function () use ( $key, $filename ) {
		mytheme_import_demo_image( 'velour', $key, $filename, __DIR__ . '/images/' . $filename );
	};
}
foreach ( $catalog['products'] as $item ) {
	$steps[] = static function () use ( $item ) {
		$sku = 'mytheme-velour-' . $item['image'];
		$existing = wc_get_product_id_by_sku( $sku );
		if ( $existing ) { update_post_meta( $existing, '_mytheme_demo', 'velour' ); return; }
		$product = new WC_Product_Simple();
		$product->set_name( $item['name'] );
		$product->set_sku( $sku );
		$product->set_regular_price( $item['price'] );
		$product->set_sale_price( $item['sale'] );
		$product->set_image_id( get_option( 'velour_image_' . $item['image'] ) );
		$terms = array();
		foreach ( $item['tags'] as $tag ) {
			$slug = 'velour-' . $tag;
			$term = get_term_by( 'slug', $slug, 'product_cat' );
			if ( $term ) { $terms[] = $term->term_id; continue; }
			$new = wp_insert_term( velour_categories()[ $tag ], 'product_cat', array( 'slug' => $slug ) );
			if ( is_wp_error( $new ) ) { throw new RuntimeException( $new->get_error_message() ); }
			$terms[] = $new['term_id'];
		}
		$product->set_category_ids( $terms );
		$id = $product->save();
		if ( ! $id ) { throw new RuntimeException( 'محصول ذخیره نشد.' ); }
		update_post_meta( $id, '_mytheme_demo', 'velour' );
	};
}
$pages = array( 'home' => 'صفحه اصلی', 'shop' => 'فروشگاه', 'contact' => 'تماس با ما', 'cart' => 'سبد خرید', 'checkout' => 'پرداخت' );
foreach ( $pages as $key => $title ) {
	$steps[] = static function () use ( $key, $title ) {
		mytheme_import_demo_page( 'velour', $key, $title );
	};
}
foreach ( $pages as $key => $title ) {
	$steps[] = static function () use ( $key ) {
		$id = get_option( 'velour_page_' . $key );
		$result = wp_update_post( array( 'ID' => $id, 'post_status' => 'publish' ), true );
		if ( is_wp_error( $result ) ) { throw new RuntimeException( $result->get_error_message() ); }
	};
}
foreach ( $pages as $key => $title ) {
	$steps[] = static function () use ( $key, $title, $catalog ) {
		$id = get_option( 'velour_page_' . $key );
		update_post_meta( $id, '_elementor_data', wp_slash( wp_json_encode( velour_layout( $key, $title, $catalog ) ) ) );
		update_post_meta( $id, '_elementor_edit_mode', 'builder' );
		update_post_meta( $id, '_elementor_template_type', 'wp-page' );
		update_post_meta( $id, '_elementor_version', ELEMENTOR_VERSION );
		update_post_meta( $id, '_wp_page_template', 'elementor_canvas' );
	};
}
$steps[] = static function () {
	\Elementor\Plugin::$instance->files_manager->clear_cache();
};
// Upgrade the two original headings without rebuilding pages edited in Elementor.
$steps[] = static function () {
	$id = get_option( 'velour_page_home' );
	$data = json_decode( get_post_meta( $id, '_elementor_data', true ), true );
	if ( ! is_array( $data ) ) { throw new RuntimeException( 'داده‌های صفحه اصلی خوانده نشد.' ); }
	$changed = false;
	$upgrade = static function ( &$nodes ) use ( &$upgrade, &$changed ) {
		foreach ( $nodes as &$node ) {
			$title = $node['settings']['title'] ?? '';
			if ( 'heading' === ( $node['widgetType'] ?? '' ) ) {
				if ( 'رز، در نورِ شب' === $title ) {
					$node['widgetType'] = 'eael-dual-color-header';
					$node['settings'] += array( 'eael_dch_first_title' => 'رز، در', 'eael_dch_last_title' => 'نورِ شب', 'title_tag' => 'h1', 'eael_dch_subtext' => '', 'eael_show_dch_separator' => '', 'eael_show_dch_icon_content' => '' );
					$changed = true;
				} elseif ( 'منتخب وِلور' === $title ) {
					$node['widgetType'] = 'premium-addon-title';
					$node['settings'] += array( 'premium_title_text' => $title, 'premium_title_tag' => 'h2' );
					$changed = true;
				}
			}
			if ( ! empty( $node['elements'] ) ) { $upgrade( $node['elements'] ); }
		}
	};
	$upgrade( $data );
	if ( $changed ) {
		update_post_meta( $id, '_elementor_data', wp_slash( wp_json_encode( $data ) ) );
		\Elementor\Plugin::$instance->files_manager->clear_cache();
	}
	update_option( 'velour_dark_widgets', true );
};
return $steps;
